function route(handle, pathname, query, response, postData) {
		console.log("About to route a request for " + pathname);
		if (typeof handle[pathname] === 'function'){
		handle[pathname](query, response, postData);
    }
    else{
		if (pathname !=='/favicon.ico'){
			console.log("No request handler found for " + pathname);
		response.writeHead(200, {"Content-Type": "text/plain"}); 
		response.write("error 404 Not found!");
		response.end();}
    }
}

exports.route = route;
